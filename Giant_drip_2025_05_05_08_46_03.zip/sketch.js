let particles = [];
let colors = ['#ffadad','#ffd6a5','#caffbf','#9bf6ff','#a0c4ff','#bdb2ff','#ffc6ff'];

let numSlider, speedSlider, sizeSlider, distSlider, resetBtn;
let fft, soundFile;

let splash;
let mode = 0;

function preload() {
  soundFile = loadSound('glacier.mp3');
}

function setup(){
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB);

  splash = new Splash();

  fft = new p5.FFT();
  fft.setInput(soundFile);

  numSlider = createSlider(100, 1000, 300, 10);
  numSlider.position(10, 10);
  
  speedSlider = createSlider(0.1, 5, 1, 0.1);
  speedSlider.position(10, 40);
  
  sizeSlider = createSlider(2, 20, 8, 1);
  sizeSlider.position(10, 70);
  
  distSlider = createSlider(20, 200, 100, 5);
  distSlider.position(10, 100);
  
  resetBtn = createButton("Reset");
  resetBtn.position(10, 130);
  resetBtn.mousePressed(makeParticles);

  makeParticles();
  background(0, 0, 5);
}

function draw(){
  if (mode == 0) {
    if (mouseIsPressed && splash.update()) {
      splash.hide();
      mode = 1;
      if (!soundFile.isPlaying()) {
        soundFile.loop();
      }
    }
  }

  if (mode == 1) {
    background(0, 0, 5, 20);
    
    let count = numSlider.value();
    let speed = speedSlider.value();
    let size = sizeSlider.value();
    let connect = distSlider.value();
    
    let freq = fft.analyze(); // 获取音频频谱

    for(let i = 0; i < particles.length; i++){
      let p = particles[i];
      let f = getFreqValue(p.pos.x, freq); // 获取每个粒子位置对应的频率值
      let s = speed * map(f, 0, 255, 0.5, 2); // 根据频率值调整粒子速度
      let sz = size * map(f, 0, 255, 0.5, 3); // 根据频率值调整粒子大小
      let colorFactor = map(f, 0, 255, 0, 255); // 调整颜色变化

      p.update(s);
      p.show(sz, colorFactor);
    }

    stroke(0, 0, 100, 10);
    strokeWeight(1);
    for(let i = 0; i < particles.length; i++){
      for(let j = i+1; j < particles.length; j++){
        let a = particles[i];
        let b = particles[j];
        let d = dist(a.pos.x, a.pos.y, b.pos.x, b.pos.y);
        if(d < connect){
          line(a.pos.x, a.pos.y, b.pos.x, b.pos.y);
        }
      }
    }
  }
}

function makeParticles(){
  particles = [];
  let n = numSlider.value();
  for(let i = 0; i < n; i++){
    let x = random(width);
    let y = random(height);
    particles.push(new Particle(x, y));
  }
}

class Particle{
  constructor(x, y){
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D();
    this.baseColor = color(random(colors));
  }

  update(s){
    let v = this.vel.copy();
    v.mult(random(0.5, s));
    this.pos.add(v);

    if(this.pos.x < 0) this.pos.x = width;
    if(this.pos.x > width) this.pos.x = 0;
    if(this.pos.y < 0) this.pos.y = height;
    if(this.pos.y > height) this.pos.y = 0;
  }

  show(sz, colorFactor){
    // 根据频率调整粒子颜色
    let dynamicColor = color(this.baseColor.levels[0] + colorFactor, this.baseColor.levels[1], this.baseColor.levels[2]);
    noStroke();
    fill(dynamicColor);
    ellipse(this.pos.x, this.pos.y, sz, sz);
  }
}

function getFreqValue(x, freq){
  let i = floor(map(x, 0, width, 0, freq.length));
  return freq[i];
}

// Original-style splash
class Splash {
  constructor() {
    this.splashBorder = 100;

    fill(255);
    stroke(255, 0, 0);
    rect(this.splashBorder, this.splashBorder, windowWidth - this.splashBorder * 2, windowHeight - this.splashBorder * 2);

    fill(0, 0, 222);
    noStroke();

    this.title = createDiv("Harmonic Particles");
    this.title.style('color:deeppink');
    this.title.style('font-family: Arial, Helvetica, sans-serif');
    this.title.style('font-size', '36px');
    this.title.position(this.splashBorder + 20, this.splashBorder + 20);

    this.name = createDiv("Xintong Yuan");
    this.name.position(this.splashBorder + 20, this.splashBorder + 60);
    this.name.style('color:white');
    this.name.style('font-size', '20px');

    this.info = createDiv(`This is an interactive audio visualization using a particle system driven by the frequency spectrum of a sound file. The particles respond in size, speed, and color to the energy of different frequency bands in real-time. <p>
    Try adjusting the sliders to control how many particles appear, how fast they move, how big they are, and how far they connect. <p>
    Click anywhere to begin. <p>
    <a href="https://editor.p5js.org/YOUR_USERNAME/sketches/YOUR_PROJECT_ID" target="_blank">View Code</a>`);
    this.info.position(this.splashBorder + 20, this.splashBorder + 100);
    this.info.size(windowWidth - this.splashBorder * 2 - 50, windowHeight - this.splashBorder * 2 - 50);
    this.info.style('font-size', '16px');
    this.info.style('color:white');
  }

  hide() {
    this.title.remove();
    this.name.remove();
    this.info.remove();
  }

  update() {
    return true;
  }
}
